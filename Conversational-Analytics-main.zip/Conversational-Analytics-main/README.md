# Conversational Analytics

A production-structured prototype for natural-language analytics over structured hospital data in PostgreSQL.

## What this module does

This module accepts hospital analytics questions in plain English, generates safe SQL with LangChain and Gemini, executes the query against PostgreSQL, and returns a clean, human-readable answer with the result rows.

## Scope

This repository contains only the Conversational Analytics module.

Included:

- Natural-language questions over structured hospital data
- SQL generation with LangChain + Gemini
- Safe PostgreSQL execution
- Structured API responses
- Validation for read-only SQL
- Logging and tests

Not included:

- RAG
- PDF retrieval
- Forecasting
- Predictive maintenance
- Multi-agent orchestration

## Tech stack

- Python
- FastAPI
- LangChain
- PostgreSQL
- SQLAlchemy / psycopg2
- Pydantic
- python-dotenv
- pytest

## Folder structure

```text
conversational_analytics/
├── app/
│   ├── main.py
│   ├── config.py
│   ├── db.py
│   ├── models.py
│   ├── analytics_service.py
│   ├── sql_safety.py
│   └── logging_config.py
├── tests/
│   ├── test_sql_safety.py
│   └── test_api.py
├── docs/
│   └── supported_queries.md
├── .env.example
├── requirements.txt
└── README.md
```

## Setup

1. Create and activate your virtual environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Copy `.env.example` to `.env` and fill in the real values.

## Environment variables

Required:

- `PGHOST`
- `PGDATABASE`
- `PGUSER`
- `PGPASSWORD`
- `GOOGLE_API_KEY`

Optional:

- `PGPORT` defaults to `5432`
- `PGSSLMODE` defaults to `require`
- `GEMINI_MODEL` defaults to `gemini-2.5-flash`
- `MAX_RESULT_ROWS` defaults to `50`
- `LLM_MAX_RETRIES` defaults to `3`
- `REQUEST_TIMEOUT_SECONDS` defaults to `30`
- `LOG_LEVEL` defaults to `INFO`

## How it works

The service uses a controlled analytics path:

1. Build the PostgreSQL connection and LangChain SQL database wrapper.
2. Initialize Gemini and the SQL toolkit.
3. Create the SQL agent for compatibility with the original prototype.
4. Generate a candidate SQL statement from the question.
5. Validate the SQL before execution.
6. Execute the query on PostgreSQL.
7. Summarize the result into a short human-readable answer.

### SQL exposure note

LangChain SQL agents do not reliably expose raw SQL before execution in every flow. For this reason, the production path in this module uses controlled SQL generation and validation before database execution, while still initializing the SQL agent to preserve the original prototype structure and keep future extensions straightforward.

## Run locally

Start the API:

```bash
uvicorn conversational_analytics.app.main:app --reload
```

Open the health endpoint:

```bash
curl http://127.0.0.1:8000/health
```

## Demo Mode (quota-safe)

For classroom or demo use where you want to avoid consuming LLM provider quota, run the service in "Demo Mode" which routes supported questions to deterministic SQL templates and disables LLM fallback.

1. Copy `.env.demo` to `.env` (or set these env vars):

```bash
cp .env.demo .env
```

2. Ensure the file contains placeholder DB values (or a read-only test DB) and DO NOT add a real `GOOGLE_API_KEY`.

3. Start the API:

```bash
uvicorn conversational_analytics.app.main:app --reload
```

4. Ask a supported template question (these are handled without LLM):

```bash
curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"question":"What is the total count of our ICU assets?"}'
```

Expected: the question is routed to a pre-defined SQL template and executed; no LLM calls are made. If the test DB is empty you may get an empty `rows` array but the `sql_query` will be the SELECT from the template.

Notes:
- To re-enable LLM fallback for exploration, set `ENABLE_LLM_FALLBACK=true` and provide a valid `GOOGLE_API_KEY` in `.env`.
- Always prefer `ENABLE_TEMPLATE_ROUTER=true` for demos to preserve provider quota.


## API usage

### POST /ask

Request:

```json
{
  "question": "Which medical device experiences the highest downtime?"
}
```

Response:

```json
{
  "question": "Which medical device experiences the highest downtime?",
  "answer": "The Infusion Pump has the highest total downtime.",
  "status": "success",
  "sql_query": "SELECT ...",
  "rows": [
    {
      "asset_name": "Infusion Pump",
      "total_downtime": 1440
    }
  ]
}
```

### cURL example

```bash
curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"question":"Top 5 assets by downtime"}'
```

## Example supported questions

- What is the total count of our ICU assets?
  - Which medical device experiences the highest downtime?
- Which spare parts are currently below the reorder level?
- Top 5 assets by downtime
- Count assets by department
- Average downtime per asset type
- Total maintenance cost by asset
- Which departments have the highest number of assets?

## Error behavior

- No rows returned: `No matching records were found for this question.`
- Gemini quota exhausted: `The analytics service is temporarily rate-limited. Please retry shortly.`
- Database connection failed: `Database connection failed.`
- Unsafe SQL: `Unsafe SQL operation detected and blocked.`

## Tests

Run:

```bash
pytest
```

## Known limitations

- Query quality depends on schema quality.
- Only SELECT queries are allowed.
- Multiple SQL statements are blocked.
- Large result sets are intentionally limited in the API response.
- This is a team-ready prototype, not a full enterprise governance layer.

## Integration notes

This module is designed to be easy to embed into a larger hospital AI platform later.

Recommended integration points:

- Mount the FastAPI app behind your platform API gateway.
- Replace the read-only PostgreSQL credentials with a dedicated reporting role.
- Add auth, authorization, and audit logging at the platform layer.
- Keep the environment variables in your deployment secret manager.
